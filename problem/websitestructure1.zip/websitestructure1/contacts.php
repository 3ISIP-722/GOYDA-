<?php
require_once 'header.php';
require_once 'db.php';

$errors = [];
$success = false;

// Обработка формы обратной связи
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $message = trim($_POST['message'] ?? '');
    $subject = trim($_POST['subject'] ?? 'Общий вопрос');
    
    // Валидация
    if (empty($name)) {
        $errors[] = 'Пожалуйста, введите ваше имя';
    }
    
    if (empty($email)) {
        $errors[] = 'Пожалуйста, введите email';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Пожалуйста, введите корректный email';
    }
    
    if (empty($message)) {
        $errors[] = 'Пожалуйста, введите ваше сообщение';
    }
    
    // Если ошибок нет, обрабатываем форму (здесь может быть отправка на email или сохранение в БД)
    if (empty($errors)) {
        // В реальном проекте здесь бы обрабатывалось сообщение, например:
        // 1. Отправка на email администратора
        // 2. Сохранение в базе данных
        
        // Для примера, просто имитируем успешную отправку
        $success = true;
        
        // Очищаем поля формы после успешной отправки
        $name = $email = $phone = $message = '';
    }
}
?>

<div class="container">
    <section class="page-header">
        <h1>Контакты</h1>
        <p>Свяжитесь с нами для получения дополнительной информации или консультации</p>
    </section>
    
    <section class="contact-info">
        <div class="contact-grid">
            <div class="contact-item">
                <div class="contact-icon">
                    <img src="img/location.svg" alt="Адрес">
                </div>
                <h3>Адрес</h3>
                <p>г. Москва, ул. Примерная, д. 123, офис 456</p>
            </div>
            
            <div class="contact-item">
                <div class="contact-icon">
                    <img src="img/phone.svg" alt="Телефон">
                </div>
                <h3>Телефон</h3>
                <p>+7 (999) 123-45-67</p>
                <p>+7 (999) 765-43-21</p>
            </div>
            
            <div class="contact-item">
                <div class="contact-icon">
                    <img src="img/email.svg" alt="Email">
                </div>
                <h3>Email</h3>
                <p>info@example.com</p>
                <p>support@example.com</p>
            </div>
            
            <div class="contact-item">
                <div class="contact-icon">
                    <img src="img/clock.svg" alt="Часы работы">
                </div>
                <h3>Часы работы</h3>
                <p>Пн-Пт: 9:00 - 18:00</p>
                <p>Сб-Вс: Выходной</p>
            </div>
        </div>
    </section>
    
    <section class="map-section">
        <h2>Наше местоположение</h2>
        <div class="map-container">
            <!-- Здесь в реальном проекте был бы iframe с картой, например Google Maps или Яндекс.Карты -->
            <div class="map-placeholder">
                <p>Карта местоположения офиса</p>
                <p><small>В реальном проекте здесь будет интерактивная карта</small></p>
            </div>
        </div>
    </section>
    
    <section class="contact-form">
        <h2>Связаться с нами</h2>
        
        <?php if ($success): ?>
            <div class="alert alert-success">
                Спасибо за ваше сообщение! Мы свяжемся с вами в ближайшее время.
            </div>
        <?php endif; ?>
        
        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php foreach($errors as $error): ?>
                        <li><?php echo htmlspecialchars($error); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="form-row">
                <div class="form-group">
                    <label for="name">Ваше имя *</label>
                    <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($name ?? ''); ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="email">Email *</label>
                    <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($email ?? ''); ?>" required>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="phone">Телефон</label>
                    <input type="tel" id="phone" name="phone" value="<?php echo htmlspecialchars($phone ?? ''); ?>">
                </div>
                
                <div class="form-group">
                    <label for="subject">Тема</label>
                    <select id="subject" name="subject">
                        <option value="Общий вопрос">Общий вопрос</option>
                        <option value="Техническая поддержка">Техническая поддержка</option>
                        <option value="Сотрудничество">Сотрудничество</option>
                        <option value="Заказ услуги">Заказ услуги</option>
                    </select>
                </div>
            </div>
            
            <div class="form-group">
                <label for="message">Сообщение *</label>
                <textarea id="message" name="message" rows="5" required><?php echo htmlspecialchars($message ?? ''); ?></textarea>
            </div>
            
            <div class="form-group">
                <button type="submit" class="btn btn-primary">Отправить сообщение</button>
            </div>
        </form>
    </section>
    
    <section class="faq">
        <h2>Часто задаваемые вопросы</h2>
        
        <div class="faq-item">
            <div class="faq-question">
                <h3>Сколько времени занимает разработка сайта?</h3>
                <div class="faq-toggle">+</div>
            </div>
            <div class="faq-answer">
                <p>Время разработки сайта зависит от сложности проекта. Простой лендинг может быть готов за 1-2 недели, а сложный интернет-магазин может занять до 2-3 месяцев.</p>
            </div>
        </div>
        
        <div class="faq-item">
            <div class="faq-question">
                <h3>Какие гарантии вы предоставляете?</h3>
                <div class="faq-toggle">+</div>
            </div>
            <div class="faq-answer">
                <p>Мы предоставляем гарантию на наши услуги в течение 6 месяцев после сдачи проекта. В этот период мы бесплатно исправляем все выявленные ошибки и неисправности.</p>
            </div>
        </div>
        
    </section>
</div>

<?php require_once 'footer.php'; ?>
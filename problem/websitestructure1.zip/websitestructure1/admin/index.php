<?php
session_start();

// Проверка авторизации и роли
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header('Location: ../index.php');
    exit;
}

require_once '../db.php';

// Обработка удаления пользователя
if (isset($_GET['delete_user']) && is_numeric($_GET['delete_user'])) {
    $user_id = (int)$_GET['delete_user'];
    
    // Нельзя удалить самого себя
    if ($user_id != $_SESSION['user']['id']) {
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        
        header('Location: index.php?message=user_deleted');
        exit;
    }
}

// Обработка изменения роли пользователя
if (isset($_GET['toggle_role']) && is_numeric($_GET['toggle_role'])) {
    $user_id = (int)$_GET['toggle_role'];
    
    // Нельзя изменить роль самому себе
    if ($user_id != $_SESSION['user']['id']) {
        // Получаем текущую роль
        $stmt = $pdo->prepare("SELECT role FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $current_role = $stmt->fetchColumn();
        
        // Меняем роль на противоположную
        $new_role = ($current_role === 'admin') ? 'user' : 'admin';
        
        $stmt = $pdo->prepare("UPDATE users SET role = ? WHERE id = ?");
        $stmt->execute([$new_role, $user_id]);
        
        header('Location: index.php?message=role_changed');
        exit;
    }
}

// Получение списка пользователей
$stmt = $pdo->query("SELECT id, name, email, role, created_at FROM users ORDER BY id DESC");
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Админ-панель</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="admin.css">
</head>
<body>
    <div class="admin-header">
        <div class="container">
            <div class="admin-header-content">
                <div class="admin-logo">
                    <a href="../index.php">
                        <img src="../img/logo.svg" alt="Логотип">
                    </a>
                    <span>Админ-панель</span>
                </div>
                <div class="admin-nav">
                    <a href="../index.php">Вернуться на сайт</a>
                    <a href="../logout.php">Выйти</a>
                </div>
            </div>
        </div>
    </div>
    
    <div class="admin-content">
        <div class="container">
            <h1>Управление пользователями</h1>
            
            <?php if (isset($_GET['message'])): ?>
                <div class="alert <?php echo $_GET['message'] === 'user_deleted' || $_GET['message'] === 'role_changed' ? 'alert-success' : 'alert-danger'; ?>">
                    <?php if ($_GET['message'] === 'user_deleted'): ?>
                        Пользователь успешно удален
                    <?php elseif ($_GET['message'] === 'role_changed'): ?>
                        Роль пользователя успешно изменена
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            
            <div class="admin-card">
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Имя</th>
                            <th>Email</th>
                            <th>Роль</th>
                            <th>Дата регистрации</th>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $user): ?>
                            <tr>
                                <td><?php echo $user['id']; ?></td>
                                <td><?php echo htmlspecialchars($user['name']); ?></td>
                                <td><?php echo htmlspecialchars($user['email']); ?></td>
                                <td>
                                    <?php if ($user['role'] === 'admin'): ?>
                                        <span class="badge badge-admin">Администратор</span>
                                    <?php else: ?>
                                        <span class="badge badge-user">Пользователь</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo date('d.m.Y H:i', strtotime($user['created_at'])); ?></td>
                                <td>
                                    <?php if ($user['id'] != $_SESSION['user']['id']): ?>
                                        <div class="admin-actions">
                                            <a href="?toggle_role=<?php echo $user['id']; ?>" class="btn btn-small btn-primary" onclick="return confirm('Вы уверены, что хотите изменить роль этого пользователя?')">
                                                <?php echo $user['role'] === 'admin' ? 'Сделать пользователем' : 'Сделать администратором'; ?>
                                            </a>
                                            <a href="?delete_user=<?php echo $user['id']; ?>" class="btn btn-small btn-danger" onclick="return confirm('Вы уверены, что хотите удалить этого пользователя?')">
                                                Удалить
                                            </a>
                                        </div>
                                    <?php else: ?>
                                        <span class="text-muted">Текущий пользователь</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <div class="admin-dashboard">
                <h2>Статистика сайта</h2>
                <div class="dashboard-grid">
                    <div class="dashboard-item">
                        <h3>Всего пользователей</h3>
                        <p class="dashboard-number"><?php echo count($users); ?></p>
                    </div>
                    <div class="dashboard-item">
                        <h3>Администраторов</h3>
                        <p class="dashboard-number">
                            <?php 
                                $admin_count = 0;
                                foreach ($users as $user) {
                                    if ($user['role'] === 'admin') {
                                        $admin_count++;
                                    }
                                }
                                echo $admin_count;
                            ?>
                        </p>
                    </div>
                    <div class="dashboard-item">
                        <h3>Обычных пользователей</h3>
                        <p class="dashboard-number">
                            <?php 
                                $user_count = 0;
                                foreach ($users as $user) {
                                    if ($user['role'] === 'user') {
                                        $user_count++;
                                    }
                                }
                                echo $user_count;
                            ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer class="admin-footer">
        <div class="container">
            <div class="copyright">
                <p>&copy; 2025 Админ-панель. Все права защищены.</p>
            </div>
        </div>
    </footer>

    <script>
        // Автоматическое скрытие уведомлений
        document.addEventListener('DOMContentLoaded', function() {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                setTimeout(() => {
                    alert.style.opacity = '0';
                    alert.style.transition = 'opacity 0.5s';
                    setTimeout(() => {
                        alert.style.display = 'none';
                    }, 500);
                }, 3000);
            });
        });
    </script>
</body>
</html>
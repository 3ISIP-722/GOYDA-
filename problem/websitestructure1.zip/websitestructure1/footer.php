</main>
    
    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-logo">
                    <a href="index.php">
                        <img src="img/logo.svg" alt="Логотип">
                    </a>
                </div>
                
                <div class="footer-links">
                    <ul>
                        <li><a href="index.php">Главная</a></li>
                        <li><a href="about.php">О нас</a></li>
                        <li><a href="services.php">Услуги</a></li>
                        <li><a href="contacts.php">Контакты</a></li>
                    </ul>
                </div>
                
                <div class="footer-contacts">
                    <p>Email: info@example.com</p>
                    <p>Телефон: +7 (999) 123-45-67</p>
                    <p>Адрес: г. Москва, ул. Примерная, д. 123</p>
                </div>
            </div>
            
            <div class="copyright">
                <p>&copy; 2025 Мой сайт. Все права защищены.</p>
            </div>
        </div>
    </footer>

    <script src="js/script.js"></script>
</body>
</html>
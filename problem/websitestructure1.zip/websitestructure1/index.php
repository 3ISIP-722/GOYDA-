<?php
require_once 'header.php';
?>

<div class="container">
    <section class="hero">
        <h1>Добро пожаловать на наш сайт</h1>
        <p>Мы рады приветствовать вас на нашем веб-ресурсе.</p>
        <a href="services.php" class="btn">Наши услуги</a>
    </section>
    
    <section class="features">
        <h2>Наши преимущества</h2>
        <div class="features-grid">
            <div class="feature-item">
                <img src="img/feature1.svg" alt="Преимущество 1">
                <h3>Качество</h3>
                <p>Мы предоставляем услуги высочайшего качества.</p>
            </div>
            <div class="feature-item">
                <img src="img/feature2.svg" alt="Преимущество 2">
                <h3>Надежность</h3>
                <p>Наша компания работает на рынке более 10 лет.</p>
            </div>
            <div class="feature-item">
                <img src="img/feature3.svg" alt="Преимущество 3">
                <h3>Доступность</h3>
                <p>Мы предлагаем доступные цены для всех наших клиентов.</p>
            </div>
        </div>
    </section>
</div>

<?php
require_once 'footer.php';
?>
-- Создание базы данных
CREATE DATABASE IF NOT EXISTS mywebsite
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE mywebsite;

-- Создание таблицы пользователей
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('user', 'admin') NOT NULL DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Добавление первого администратора
INSERT INTO users (name, email, password, role)
VALUES ('Администратор', 'admin@example.com', '$2y$10$q06HMjSuPZ9Qh1U3fTjzr.Q1A7Yn2LGMoFdOY.D80EFeEx/Y1Pv7G', 'admin');
-- Пароль: admin123
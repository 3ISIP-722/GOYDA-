<?php
session_start();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Мой сайт</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">
                <a href="index.php">
                    <img src="img/logo.svg" alt="Логотип">
                </a>
            </div>
            
            <div class="burger-menu">
                <div class="burger-icon">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
            
            <nav class="main-menu">
                <ul>
                    <li><a href="index.php">Главная</a></li>
                    <li><a href="about.php">О нас</a></li>
                    <li><a href="services.php">Услуги</a></li>
                    <li><a href="contacts.php">Контакты</a></li>
                </ul>
            </nav>
            
            <div class="auth-buttons">
                <?php if(isset($_SESSION['user'])): ?>
                    <span class="user-info">
                        Привет, <?php echo htmlspecialchars($_SESSION['user']['name']); ?>
                        <?php if($_SESSION['user']['role'] == 'admin'): ?>
                            <a href="admin/index.php" class="admin-link">Админ панель</a>
                        <?php endif; ?>
                    </span>
                    <a href="logout.php" class="btn">Выйти</a>
                <?php else: ?>
                    <a href="auth.php" class="btn">Вход</a>
                    <a href="reg.php" class="btn">Регистрация</a>
                <?php endif; ?>
            </div>
        </div>
    </header>
    
    <div class="sidebar">
        <div class="sidebar-close">&times;</div>
        <div class="logo">
            <a href="index.php">
                <img src="img/logo.svg" alt="Логотип">
            </a>
        </div>
        <nav class="sidebar-menu">
            <ul>
                <li><a href="index.php">Главная</a></li>
                <li><a href="about.php">О нас</a></li>
                <li><a href="services.php">Услуги</a></li>
                <li><a href="contacts.php">Контакты</a></li>
            </ul>
        </nav>
        <div class="sidebar-auth">
            <?php if(isset($_SESSION['user'])): ?>
                <span class="user-info">
                    Привет, <?php echo htmlspecialchars($_SESSION['user']['name']); ?>
                </span>
                <?php if($_SESSION['user']['role'] == 'admin'): ?>
                    <a href="admin/index.php" class="btn">Админ панель</a>
                <?php endif; ?>
                <a href="logout.php" class="btn">Выйти</a>
            <?php else: ?>
                <a href="auth.php" class="btn">Вход</a>
                <a href="reg.php" class="btn">Регистрация</a>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="overlay"></div>
    
    <main>
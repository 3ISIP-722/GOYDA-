<?php
require_once 'header.php';
?>

<div class="container">
    <section class="page-header">
        <h1>О нас</h1>
    </section>
    
    <section class="about-content">
        <div class="about-image">
            <img src="img/about-us.jpg" alt="О нашей компании">
        </div>
        
        <div class="about-text">
            <h2>Наша история</h2>
            <p>Мы начали свою деятельность в 2015 году как небольшая команда профессионалов, объединенных общей идеей. За это время мы значительно выросли и укрепили свои позиции на рынке.</p>
            
            <h2>Наша миссия</h2>
            <p>Наша миссия заключается в предоставлении качественных услуг, которые помогают нашим клиентам достигать поставленных целей и решать свои задачи эффективно и в срок.</p>
            
            <h2>Наша команда</h2>
            <p>В нашей компании работает более 50 специалистов высокого уровня, каждый из которых является экспертом в своей области. Мы постоянно развиваемся и совершенствуем свои навыки.</p>
            
            <h2>Наши ценности</h2>
            <ul class="values-list">
                <li><strong>Качество</strong> - мы не идем на компромиссы в вопросах качества наших услуг</li>
                <li><strong>Надежность</strong> - мы всегда выполняем свои обязательства перед клиентами</li>
                <li><strong>Инновации</strong> - мы постоянно ищем новые подходы и решения</li>
                <li><strong>Клиентоориентированность</strong> - интересы клиента всегда на первом месте</li>
            </ul>
        </div>
    </section>
    
    <section class="team">
        <h2>Ключевые сотрудники</h2>
        <div class="team-grid">
            <div class="team-member">
                <img src="img/team1.jpg" alt="Иван Иванов">
                <h3>Иван Иванов</h3>
                <p class="position">Генеральный директор</p>
                <p>Более 15 лет опыта работы в отрасли. Отвечает за стратегическое развитие компании.</p>
            </div>
            <div class="team-member">
                <img src="img/team2.jpg" alt="Елена Петрова">
                <h3>Елена Петрова</h3>
                <p class="position">Технический директор</p>
                <p>Эксперт в области современных технологий. Руководит техническим отделом компании.</p>
            </div>
            <div class="team-member">
                <img src="img/team3.jpg" alt="Алексей Сидоров">
                <h3>Алексей Сидоров</h3>
                <p class="position">Руководитель отдела продаж</p>
                <p>Специалист по работе с клиентами. Отвечает за развитие клиентской базы.</p>
            </div>
        </div>
    </section>
    
    <section class="achievements">
        <h2>Наши достижения</h2>
        <div class="achievements-grid">
            <div class="achievement-item">
                <div class="achievement-number">500+</div>
                <div class="achievement-text">Успешно реализованных проектов</div>
            </div>
            <div class="achievement-item">
                <div class="achievement-number">300+</div>
                <div class="achievement-text">Довольных клиентов</div>
            </div>
            <div class="achievement-item">
                <div class="achievement-number">10+</div>
                <div class="achievement-text">Лет на рынке</div>
            </div>
            <div class="achievement-item">
                <div class="achievement-number">50+</div>
                <div class="achievement-text">Профессиональных сотрудников</div>
            </div>
        </div>
    </section>
</div>

<style>
.page-header {
    text-align: center;
    padding: 40px 0;
}

.about-content {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 40px;
    margin-bottom: 50px;
}

.about-image img {
    width: 100%;
    border-radius: 8px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
}

.about-text h2 {
    margin-top: 30px;
    margin-bottom: 15px;
}

.about-text h2:first-child {
    margin-top: 0;
}

.about-text p {
    margin-bottom: 20px;
    line-height: 1.7;
}

.values-list {
    list-style-type: circle;
    padding-left: 20px;
}

.values-list li {
    margin-bottom: 10px;
}

.team {
    margin-bottom: 60px;
}

.team h2 {
    text-align: center;
    margin-bottom: 40px;
}

.team-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 30px;
}

.team-member {
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1);
    padding: 30px;
    text-align: center;
}

.team-member img {
    width: 150px;
    height: 150px;
    border-radius: 50%;
    object-fit: cover;
    margin-bottom: 20px;
}

.team-member h3 {
    margin-bottom: 5px;
}

.team-member .position {
    color: #007bff;
    font-weight: 600;
    margin-bottom: 15px;
}

.achievements {
    margin-bottom: 60px;
}

.achievements h2 {
    text-align: center;
    margin-bottom: 40px;
}

.achievements-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 30px;
}

.achievement-item {
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1);
    padding: 30px;
    text-align: center;
}

.achievement-number {
    font-size: 3rem;
    font-weight: 700;
    color: #007bff;
    margin-bottom: 10px;
}

@media (max-width: 768px) {
    .about-content {
        grid-template-columns: 1fr;
    }
}
</style>

<?php
require_once 'footer.php';
?>
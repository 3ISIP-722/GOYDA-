<?php
$host = 'localhost';
$dbname = 'mywebsite';
$user = 'root';
$password = 'root';

try {
    // Вначале попробуйте подключиться только к серверу MySQL без указания базы данных
    $pdo = new PDO("mysql:host=$host;charset=utf8", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Подключение к MySQL успешно установлено<br>";
    
    // Теперь попробуйте выбрать базу данных
    $pdo->exec("USE $dbname");
    echo "База данных $dbname успешно выбрана";
} catch (PDOException $e) {
    die("Ошибка: " . $e->getMessage());
}
?>
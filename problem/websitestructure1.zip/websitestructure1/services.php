<?php
require_once 'header.php';
?>

<div class="container">
    <section class="page-header">
        <h1>Наши услуги</h1>
        <p>Мы предоставляем широкий спектр профессиональных услуг для решения ваших задач</p>
    </section>
    
    <section class="services-list">
        <div class="service-item">
            <div class="service-icon">
                <img src="img/service1.svg" alt="Услуга 1">
            </div>
            <div class="service-content">
                <h2>Веб-разработка</h2>
                <p>Создаем современные, функциональные и отзывчивые веб-сайты с использованием передовых технологий. Наши решения адаптированы под потребности вашего бизнеса и оптимизированы для поисковых систем.</p>
                <ul class="service-features">
                    <li>Разработка корпоративных сайтов</li>
                    <li>Создание интернет-магазинов</li>
                    <li>Разработка лендингов</li>
                    <li>Редизайн существующих сайтов</li>
                </ul>
                <a href="contacts.php" class="btn">Заказать</a>
            </div>
        </div>
        
        <div class="service-item">
            <div class="service-icon">
                <img src="img/service2.svg" alt="Услуга 2">
            </div>
            <div class="service-content">
                <h2>Мобильная разработка</h2>
                <p>Разрабатываем мобильные приложения для iOS и Android, которые отличаются высокой функциональностью, стабильностью работы и интуитивно понятным интерфейсом.</p>
                <ul class="service-features">
                    <li>Приложения для iOS</li>
                    <li>Приложения для Android</li>
                    <li>Кроссплатформенная разработка</li>
                    <li>Поддержка и обновление приложений</li>
                </ul>
                <a href="contacts.php" class="btn">Заказать</a>
            </div>
        </div>
        
        <div class="service-item">
            <div class="service-icon">
                <img src="img/service3.svg" alt="Услуга 3">
            </div>
            <div class="service-content">
                <h2>Дизайн и UI/UX</h2>
                <p>Создаем привлекательные и функциональные интерфейсы, которые помогают улучшить пользовательский опыт и повысить конверсию вашего сайта или приложения.</p>
                <ul class="service-features">
                    <li>UI/UX дизайн</li>
                    <li>Проектирование интерфейсов</li>
                    <li>Разработка фирменного стиля</li>
                    <li>Создание дизайн-систем</li>
                </ul>
                <a href="contacts.php" class="btn">Заказать</a>
            </div>
        </div>
        
        <div class="service-item">
            <div class="service-icon">
                <img src="img/service4.svg" alt="Услуга 4">
            </div>
            <div class="service-content">
                <h2>Поддержка и сопровождение</h2>
                <p>Оказываем услуги по технической поддержке и сопровождению веб-сайтов и мобильных приложений. Обеспечиваем стабильную работу вашего проекта и оперативно реагируем на возникающие вопросы.</p>
                <ul class="service-features">
                    <li>Техническая поддержка 24/7</li>
                    <li>Мониторинг работоспособности</li>
                    <li>Обновление и масштабирование</li>
                    <li>Администрирование серверов</li>
                </ul>
                <a href="contacts.php" class="btn">Заказать</a>
            </div>
        </div>
    </section>
    
    <section class="pricing">
        <h2>Наши тарифы</h2>
        <div class="pricing-grid">
            <div class="pricing-item">
                <div class="pricing-header">
                    <h3>Базовый</h3>
                    <div class="pricing-price">от 30 000 ₽</div>
                </div>
                <div class="pricing-features">
                    <ul>
                        <li>Разработка лендинга</li>
                        <li>До 5 страниц</li>
                        <li>Базовая SEO-оптимизация</li>
                        <li>Адаптивный дизайн</li>
                        <li>Поддержка в течение 1 месяца</li>
                    </ul>
                </div>
                <div class="pricing-footer">
                    <a href="contacts.php" class="btn">Выбрать</a>
                </div>
            </div>
            
            <div class="pricing-item featured">
                <div class="pricing-badge">Популярный</div>
                <div class="pricing-header">
                    <h3>Стандарт</h3>
                    <div class="pricing-price">от 60 000 ₽</div>
                </div>
                <div class="pricing-features">
                    <ul>
                        <li>Корпоративный сайт</li>
                        <li>До 15 страниц</li>
                        <li>Полная SEO-оптимизация</li>
                        <li>Система управления контентом</li>
                        <li>Интеграция с CRM</li>
                        <li>Поддержка в течение 3 месяцев</li>
                    </ul>
                </div>
                <div class="pricing-footer">
                    <a href="contacts.php" class="btn">Выбрать</a>
                </div>
            </div>
            
            <div class="pricing-item">
                <div class="pricing-header">
                    <h3>Премиум</h3>
                    <div class="pricing-price">от 100 000 ₽</div>
                </div>
                <div class="pricing-features">
                    <ul>
                        <li>Интернет-магазин или сложный портал</li>
                        <li>Неограниченное количество страниц</li>
                        <li>Продвинутая SEO-оптимизация</li>
                        <li>Интеграция с платежными системами</li>
                        <li>Внедрение аналитики</li>
                        <li>Поддержка в течение 6 месяцев</li>
                    </ul>
                </div>
                <div class="pricing-footer">
                    <a href="contacts.php" class="btn">Выбрать</a>
                </div>
            </div>
        </div>
    </section>
    
    <section class="testimonials">
        <h2>Отзывы клиентов</h2>
        <div class="testimonials-grid">
            <div class="testimonial-item">
                <div class="testimonial-text">
                    <p>"Работа выполнена качественно и в срок. Очень довольны результатом. Будем обращаться еще!"</p>
                </div>
                <div class="testimonial-author">
                    <img src="img/client1.jpg" alt="Клиент 1">
                    <div>
                        <h4>Анна Смирнова</h4>
                        <p>ООО "Вектор"</p>
                    </div>
                </div>
            </div>
            
            <div class="testimonial-item">
                <div class="testimonial-text">
                    <p>"Профессиональный подход к делу. Все наши требования были учтены, а сроки соблюдены. Спасибо за отличную работу!"</p>
                </div>
                <div class="testimonial-author">
                    <img src="img/client2.jpg" alt="Клиент 2">
                    <div>
                        <h4>Дмитрий Козлов</h4>
                        <p>ИП "Технологии"</p>
                    </div>
                </div>
            </div>
            
            <div class="testimonial-item">
                <div class="testimonial-text">
                    <p>"Сотрудничество с этой компанией было одним из лучших решений для нашего бизнеса. Сайт, который они разработали, превзошел все наши ожидания."</p>
                </div>
                <div class="testimonial-author">
                    <img src="img/client3.jpg" alt="Клиент 3">
                    <div>
                        <h4>Елена Соколова</h4>
                        <p>ООО "Горизонт"</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<style>
.page-header {
    text-align: center;
    padding: 40px 0;
}

.page-header p {
    max-width: 600px;
    margin: 20px auto 0;
}

.services-list {
    margin-bottom: 60px;
}

.service-item {
    display: flex;
    margin-bottom: 40px;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1);
    overflow: hidden;
}

.service-icon {
    background-color: #f8f9fa;
    padding: 30px;
    display: flex;
    align-items: center;
    justify-content: center;
    min-width: 200px;
}

.service-icon img {
    width: 100px;
    height: 100px;
}

.service-content {
    padding: 30px;
    flex: 1;
}

.service-content h2 {
    margin-bottom: 15px;
    color: #007bff;
}

.service-content p {
    margin-bottom: 20px;
    line-height: 1.7;
}

.service-features {
    margin-bottom: 25px;
    padding-left: 20px;
}

.service-features li {
    margin-bottom: 8px;
    position: relative;
    list-style-type: circle;
}

.pricing {
    margin-bottom: 60px;
}

.pricing h2 {
    text-align: center;
    margin-bottom: 40px;
}

.pricing-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 30px;
}

.pricing-item {
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1);
    overflow: hidden;
    position: relative;
}

.pricing-badge {
    position: absolute;
    top: 0;
    right: 0;
    background-color: #28a745;
    color: #fff;
    padding: 5px 15px;
    font-size: 0.85rem;
    font-weight: 600;
    border-bottom-left-radius: 8px;
}

.pricing-header {
    padding: 30px;
    text-align: center;
    border-bottom: 1px solid #eee;
}

.pricing-header h3 {
    margin-bottom: 15px;
}

.pricing-price {
    font-size: 1.8rem;
    font-weight: 700;
    color: #007bff;
}

.pricing-features {
    padding: 30px;
}

.pricing-features ul {
    list-style-type: none;
}

.pricing-features li {
    margin-bottom: 15px;
    padding-left: 25px;
    position: relative;
}

.pricing-features li:before {
    content: "✓";
    position: absolute;
    left: 0;
    color: #28a745;
    font-weight: 600;
}

.pricing-footer {
    padding: 15px 30px 30px;
    text-align: center;
}

.featured {
    transform: scale(1.05);
    z-index: 10;
    box-shadow: 0 5px 20px rgba(0, 0, 0, 0.15);
}

.testimonials {
    margin-bottom: 60px;
}

.testimonials h2 {
    text-align: center;
    margin-bottom: 40px;
}

.testimonials-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 30px;
}

.testimonial-item {
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1);
    padding: 30px;
}

.testimonial-text {
    margin-bottom: 20px;
    font-style: italic;
}

.testimonial-author {
    display: flex;
    align-items: center;
}

.testimonial-author img {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    margin-right: 15px;
}

.testimonial-author h4 {
    margin-bottom: 5px;
}

.testimonial-author p {
    color: #6c757d;
    font-size: 0.9rem;
}

@media (max-width: 768px) {
    .service-item {
        flex-direction: column;
    }
    
    .service-icon {
        min-width: auto;
    }
    
    .featured {
        transform: none;
    }
}
</style>

<?php
require_once 'footer.php';
?>
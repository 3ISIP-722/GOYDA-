<?php
require_once 'db.php';
require_once 'header.php';

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    
    // Валидация
    if (empty($email)) {
        $errors[] = 'Введите email';
    }
    
    if (empty($password)) {
        $errors[] = 'Введите пароль';
    }
    
    // Проверка пользователя
    if (empty($errors)) {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user && password_verify($password, $user['password'])) {
            // Авторизация успешна
            $_SESSION['user'] = [
                'id' => $user['id'],
                'name' => $user['name'],
                'email' => $user['email'],
                'role' => $user['role']
            ];
            
            header('Location: index.php');
            exit;
        } else {
            $errors[] = 'Неверный email или пароль';
        }
    }
}
?>

<div class="container">
    <div class="auth-form">
        <h1>Вход</h1>
        
        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php foreach($errors as $error): ?>
                        <li><?php echo htmlspecialchars($error); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($email ?? ''); ?>">
            </div>
            
            <div class="form-group">
                <label for="password">Пароль</label>
                <input type="password" id="password" name="password">
            </div>
            
            <button type="submit" class="btn btn-primary">Войти</button>
        </form>
        
        <div class="auth-links">
            <p>Нет аккаунта? <a href="reg.php">Зарегистрироваться</a></p>
        </div>
    </div>
</div>

<?php
require_once 'footer.php';
?>